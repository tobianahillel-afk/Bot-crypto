#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]

STEPS: list[tuple[list[str], int]] = [
    (["python", "scripts/validate_all_until_lot19.py"], 300),
    (["python", "scripts/validate_lot20.py"], 60),
    (["python", "scripts/validate_lot20_archive_extracted.py"], 180),
    (["python", "scripts/validate_v1_archive_frozen.py"], 120),
    (["python", "scripts/run_lot21_product_scope.py"], 60),
    (["python", "scripts/validate_lot21.py"], 60),
]


def main() -> int:
    for command, timeout_seconds in STEPS:
        result = subprocess.run(
            command,
            cwd=ROOT,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
        if result.returncode != 0:
            return int(result.returncode)
    print("LOT 21 ORCHESTRATED VALIDATION: PASS", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
