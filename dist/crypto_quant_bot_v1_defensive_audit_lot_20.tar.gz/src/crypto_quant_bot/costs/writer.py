import json
from pathlib import Path
from typing import Any

from crypto_quant_bot.contracts.costs import TransactionCostEstimate, TransactionCostRunResult


def write_json(path: Path | str, payload: dict[str, Any]) -> None:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = file_path.with_name(f".{file_path.name}.tmp")
    tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    tmp_path.replace(file_path)


def write_estimates(path: Path | str, estimates: list[TransactionCostEstimate]) -> None:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    text = "\n".join(json.dumps(estimate.to_dict(), ensure_ascii=False, sort_keys=True) for estimate in estimates)
    tmp_path = file_path.with_name(f".{file_path.name}.tmp")
    tmp_path.write_text(text + ("\n" if estimates else ""), encoding="utf-8")
    tmp_path.replace(file_path)


def write_run_result(path: Path | str, result: TransactionCostRunResult) -> None:
    write_json(path, result.to_dict())


def write_report(path: Path | str, result: TransactionCostRunResult, counts_by_timeframe: dict[str, int]) -> None:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    text = (
        "# Lot 10 Transaction Costs Report\n\n"
        "Transaction Costs, Spread & Slippage Model V0 estime uniquement des coûts hypothétiques neutres.\n\n"
        f"Run id: `{result.run_id}`\n\n"
        f"5m estimates: {counts_by_timeframe.get('5m', 0)}\n\n"
        f"15m estimates: {counts_by_timeframe.get('15m', 0)}\n\n"
        f"Estimate count: {result.estimate_count}\n\n"
        f"Average total cost bps: {result.average_total_cost_bps}\n\n"
        f"Min total cost bps: {result.min_total_cost_bps}\n\n"
        f"Max total cost bps: {result.max_total_cost_bps}\n\n"
        f"Orders created count: {result.orders_created_count}\n\n"
        f"Fills created count: {result.fills_created_count}\n\n"
        f"PnL total: {result.pnl_total}\n\n"
        f"Trade allowed: {str(result.trade_allowed).lower()}\n\n"
        f"Used for decision: {str(result.used_for_decision).lower()}\n\n"
        "Ce lot ne crée aucune stratégie, aucun ordre, aucun fill, aucun PnL exploitable et aucun signal LONG/SHORT.\n"
    )
    tmp_path = file_path.with_name(f".{file_path.name}.tmp")
    tmp_path.write_text(text, encoding="utf-8")
    tmp_path.replace(file_path)
