import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Iterable


def _to_jsonable(record: Any) -> Any:
    if hasattr(record, "to_dict"):
        return record.to_dict()
    if is_dataclass(record):
        return asdict(record)
    return record


def write_jsonl(records: Iterable[Any], path: Path | str) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    lines = [json.dumps(_to_jsonable(record), ensure_ascii=False, sort_keys=True) for record in records]
    output.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return output
