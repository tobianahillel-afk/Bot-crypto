import json
from pathlib import Path
from typing import Any


def read_jsonl(path: Path | str) -> list[dict[str, Any]]:
    file_path = Path(path)
    if not file_path.exists():
        return []
    return [json.loads(line) for line in file_path.read_text(encoding="utf-8").splitlines() if line.strip()]


def index_by_timestamp(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {str(row.get("timestamp")): row for row in rows if row.get("timestamp") is not None}


def group_by_timestamp(rows: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        timestamp = row.get("timestamp")
        if timestamp is None:
            continue
        grouped.setdefault(str(timestamp), []).append(row)
    return grouped
