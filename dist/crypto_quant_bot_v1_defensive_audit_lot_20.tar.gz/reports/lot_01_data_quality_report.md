# Lot 1 Data Quality Report

Dataset ID: btc_eur_1m_ohlcvt_sample_lot1bis
Dataset name: BTC/EUR OHLCVT official Lot 1-bis fixture
Pair: BTC/EUR
Timeframe: 1m
Source: tests_fixture_lot1bis
Bronze path: /mnt/hgfs/Forensic/Bot-crypto/crypto_quant_bot/data/bronze/btc_eur_ohlcvt_sample_lot1bis.jsonl
Rows: 6
Quality flag: valid
Duplicate rows: 0
Invalid rows: 0
Negative volume: False
OHLC inconsistency: False
Checksum: 7cb9e6a24bbd6bd63c95ea9e32ed7aabc4e5db90f5a3c3b4c167b66ed4283407
Errors: []
Warnings: []

Decision: VALID
