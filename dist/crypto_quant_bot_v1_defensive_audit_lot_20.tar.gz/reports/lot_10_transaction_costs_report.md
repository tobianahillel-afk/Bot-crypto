# Lot 10 Transaction Costs Report

Transaction Costs, Spread & Slippage Model V0 estime uniquement des coûts hypothétiques neutres.

Run id: `lot10_costs_4d594402-ee59-4835-a417-f5c33cc5ba2a`

5m estimates: 36

15m estimates: 12

Estimate count: 48

Average total cost bps: 80.27697712

Min total cost bps: 41.0

Max total cost bps: 186.0010886

Orders created count: 0

Fills created count: 0

PnL total: 0

Trade allowed: false

Used for decision: false

Ce lot ne crée aucune stratégie, aucun ordre, aucun fill, aucun PnL exploitable et aucun signal LONG/SHORT.
